package spell;

public class Trie implements ITrie{

    INode root;
    int myWords;
    int myNodes;

    public Trie(){
        root = new Node();
    }
    @Override
    public void add(String word) {
        INode currNode = root;
        for(int i = 0; i < word.length(); i++) {
            int charNum = (int)(word.charAt(i) - 'a');
            if(currNode.getChildren()[charNum] != null) {
                currNode = currNode.getChildren()[charNum];
            }
            else {
                currNode.addChild(charNum);
                currNode = currNode.getChildren()[charNum];
                myNodes++;
            }
        }
        currNode.incrementValue();
        myWords++;
    }

    @Override
    public INode find(String word) {
        INode currNode = root;
        for(int i = 0; i < word.length(); i++) {
            int charNum = (int)(word.charAt(i) - 'a');
            if(currNode.getChildren()[charNum] != null) {
                currNode = currNode.getChildren()[charNum];
                if((i == word.length()-1) && (currNode.getValue() > 0)) {
                    return currNode;
                }
            } else {
                return null;
            }
        }
        return null;
    }

    @Override
    public int getWordCount() {
        return getWordsRecursive(root);
    }

    private int getWordsRecursive(INode currNode) {
        int wordCount = 0;
        for(int i = 0; i < currNode.getChildren().length; i++) {
            if(currNode.getChildren()[i] != null) {
                if(currNode.getChildren()[i].getValue() > 0) wordCount++;
                INode myNode = currNode.getChildren()[i];
                wordCount += getWordsRecursive(myNode);
            }
        }
        return wordCount;
    }

    @Override
    public int getNodeCount() {
        return getNodesRecursive(root);
    }

    private int getNodesRecursive(INode currNode) {
        int nodeCount = 1;
        for(int i = 0; i < currNode.getChildren().length; i++) {
            if(currNode.getChildren()[i] != null) {
                nodeCount += getNodesRecursive(currNode.getChildren()[i]);
            }
        }
        return nodeCount;
    }

    @Override
    public String toString(){
        StringBuilder allWords = new StringBuilder();
        for(int i = 0; i < root.getChildren().length; i++) {
            StringBuilder currWord = new StringBuilder();
            if (root.getChildren()[i] != null) {
                currWord.append((char) ('a' + i));
                //System.out.println((char)('a' + i));
                currWord.append(recursiveToString(root.getChildren()[i], currWord, allWords));
                currWord.deleteCharAt(currWord.length() - 1);
                //System.out.println("curr: " + currWord.toString());
            }
        }
        //System.out.println("root: " + root.getValue());
        //System.out.println(allWords.toString());
        return allWords.toString();
    }
    private String recursiveToString(INode node, StringBuilder currWord, StringBuilder allWords) {
        if(node.getValue() > 0) {
            allWords.append(currWord);
            allWords.append('\n');
        }
        for(int i = 0; i < node.getChildren().length; i++) {
            if(node.getChildren()[i] != null) {
                currWord.append((char)('a' + i));
                //System.out.println((char)('a' + i));
                currWord.append(recursiveToString(node.getChildren()[i], currWord, allWords));
                currWord.deleteCharAt(currWord.length() - 1);
                //System.out.println("curr: " + currWord.toString());
            }
        }
        return allWords.toString();
    }


    @Override
    public int hashCode() {
        int myHash = myWords * myNodes;
        for(int i = 0; i < root.getChildren().length; i++) {
            if(root.getChildren()[i] != null) {
                myHash += i;
            }
        }
        //System.out.println("hash: " + myHash);
        return myHash;
    }

    @Override
    public boolean equals(Object o) {
        if(o.getClass() != getClass()) return false;
        Trie testEqual = (Trie)o;
        return root.equals(testEqual.root);
    }
}
