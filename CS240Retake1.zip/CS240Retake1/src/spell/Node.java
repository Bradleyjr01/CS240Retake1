package spell;

public class Node implements INode {

    private int value;
    private Node[] children;

    Node() {
        value = 0;
        children = new Node[26];
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public void incrementValue() {
        value++;
    }

    @Override
    public INode[] getChildren() {
        return children;
    }

    public void addChild(int pos) {
        children[pos] = new Node();
    }

    @Override
    public boolean equals(Object o) {
        if(o.getClass() != getClass()) return false;
        Node testEqual = (Node)o;
        if(testEqual.getValue() != getValue()) return false;
        for(int i = 0; i < getChildren().length; i++) {
            if(testEqual.getChildren()[i] == null && getChildren()[i] == null) continue;
            if(testEqual.getChildren()[i] != null && getChildren()[i] == null) return false;
            if(testEqual.getChildren()[i] == null && getChildren()[i] != null) return false;
            if(!testEqual.getChildren()[i].equals(getChildren()[i])) return false;
        }
        return true;
    }
}
