package spell;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class SpellCorrector implements ISpellCorrector{

    ITrie dictionary;
    @Override
    public void useDictionary(String dictionaryFileName) throws IOException {
        ITrie myDictionary = new Trie();
        try {
            File myFile = new File(dictionaryFileName);
            if(!myFile.exists()) throw new IOException();
            Scanner readFile = new Scanner(myFile);
            while (readFile.hasNext()) {
                myDictionary.add(readFile.next());
            }
            dictionary = myDictionary;
        } catch (IOException ex){

        }
    }

    @Override
    public String suggestSimilarWord(String inputWord) {
        String lowerCase = inputWord.toLowerCase();
        if(dictionary.find(lowerCase) != null) {
            //System.out.println("found given: " + lowerCase);
            return lowerCase;
        }

        ArrayList<String> distanceOneWords = editDistanceOne(lowerCase);
        if(!distanceOneWords.isEmpty()) {
            if(distanceOneWords.size() == 1) {
                //System.out.println("one word: " + distanceOneWords.get(0));
                return distanceOneWords.get(0);
            }

            //most occurances
            int[] numOccurances = new int[distanceOneWords.size()];
            int greatestOccurPos = 0;
            int greatestOccur = 0;
            boolean multipleOccur = false;
            for(int i = 0 ; i < numOccurances.length; i++) {
                int myOccurances = dictionary.find(distanceOneWords.get(i)).getValue();
                if(myOccurances == greatestOccur && !distanceOneWords.get(i).equals(distanceOneWords.get(greatestOccurPos))) multipleOccur = true;
                else if(myOccurances > greatestOccur) {
                    greatestOccur = myOccurances;
                    greatestOccurPos = i;
                    multipleOccur = false;
                }
            }
            if(!multipleOccur) {
                //System.out.println("greatest count : " + distanceOneWords.get(greatestOccurPos));
                return distanceOneWords.get(greatestOccurPos);
            }

            //alpha
            //System.out.println("alpha:" + distanceOneWords.get(0));
            return distanceOneWords.get(0);
        }

        ArrayList<String> distanceTwoWords = editDistanceTwo(lowerCase);
        if(!distanceTwoWords.isEmpty()) {
            if(distanceTwoWords.size() == 1) {
                //System.out.println("one word: " + distanceTwoWords.get(0));
                return distanceTwoWords.get(0);
            }

            //most occurances
            int[] numOccurances = new int[distanceTwoWords.size()];
            int greatestOccurPos = 0;
            int greatestOccur = 0;
            boolean multipleOccur = false;
            for(int i = 0 ; i < numOccurances.length; i++) {
                int myOccurances = dictionary.find(distanceTwoWords.get(i)).getValue();
                //System.out.println(distanceTwoWords.get(i) + " occurs " + myOccurances + " time(s)");
                if(myOccurances == greatestOccur && !distanceTwoWords.get(i).equals(distanceTwoWords.get(greatestOccurPos))) {
                    //System.out.println("This is getting out of hand, now there are two of them!");
                    multipleOccur = true;
                }
                else if(myOccurances > greatestOccur) {
                    //System.out.println(distanceTwoWords.get(i) + ": \"I am the captain now!\"  (" + myOccurances + ")");
                    greatestOccur = myOccurances;
                    greatestOccurPos = i;
                    multipleOccur = false;
                }
            }
            if(!multipleOccur) {
                //System.out.println("greatest count : " + distanceTwoWords.get(greatestOccurPos));
                //System.out.println("count: " + greatestOccur);
                return distanceTwoWords.get(greatestOccurPos);
            }

            //alpha
            //System.out.println("alpha:" + distanceTwoWords.get(0));
            return distanceTwoWords.get(0);
        }

        return null;
    }

    private ArrayList<String> editDistanceOne(String word) {
        ArrayList<String> distanceOne = new ArrayList<String>();
        //deletion
        for(int i = 0; i < word.length(); i++) {
            StringBuilder deletion = new StringBuilder(word);
            deletion.deleteCharAt(i);
            if(dictionary.find(deletion.toString()) != null) {
                //System.out.println("del added:" + deletion.toString());
                distanceOne.add(deletion.toString());
            }
        }
        //transposition
        for(int i = 0; i < word.length() - 1; i++) {
            StringBuilder transposition = new StringBuilder(word);
            char charOne = word.charAt(i);
            char charTwo = word.charAt(i+1);
            String transposed = String.valueOf(charTwo) +
                    charOne;
            //System.out.println("Transpose: " + transposed.toString());
            transposition.replace(i,i+2, transposed);
            if(dictionary.find(transposition.toString()) != null) {
                //System.out.println("tran added:" + transposition.toString());
                distanceOne.add(transposition.toString());
            }
        }
        //alteration
        for(int i = 0; i < word.length(); i++) {
            for(int c = 0; c < 26; c++) {
                StringBuilder alteration = new StringBuilder(word);
                String letterAlter = (char)('a' + c) + "";
                alteration.replace(i,i+1, letterAlter);
                if (dictionary.find(alteration.toString()) != null) {
                    //System.out.println("alt added:" + alteration.toString());
                    distanceOne.add(alteration.toString());
                }
            }
        }
        //insertion
        for(int i = 0; i < word.length() + 1; i++) {
            for(int c = 0; c < 26; c++) {
                StringBuilder insertion = new StringBuilder(word);
                String letterInsert = (char)('a' + c) + "";
                insertion.insert(i,letterInsert);
                if (dictionary.find(insertion.toString()) != null) {
                    //System.out.println("ins added:" + insertion.toString());
                    distanceOne.add(insertion.toString());
                }
            }
        }

        return distanceOne;
    }

    private ArrayList<String> editDistanceTwo(String word) {
        ArrayList<String> distanceTwo = new ArrayList<String>();
        //deletion
        for(int i = 0; i < word.length(); i++) {
            StringBuilder deletion = new StringBuilder(word);
            deletion.deleteCharAt(i);
            distanceTwo.addAll(editDistanceOne(deletion.toString()));
        }
        //transposition
        for(int i = 0; i < word.length() - 1; i++) {
            StringBuilder transposition = new StringBuilder(word);
            char charOne = word.charAt(i);
            char charTwo = word.charAt(i+1);
            String transposed = String.valueOf(charTwo) +
                    charOne;
            //System.out.println("Transpose: " + transposed.toString());
            transposition.replace(i,i+2, transposed);
            distanceTwo.addAll(editDistanceOne(transposition.toString()));
        }
        //alteration
        for(int i = 0; i < word.length(); i++) {
            for(int c = 0; c < 26; c++) {
                StringBuilder alteration = new StringBuilder(word);
                String letterAlter = (char)('a' + c) + "";
                alteration.replace(i,i+1,letterAlter);
                distanceTwo.addAll(editDistanceOne(alteration.toString()));
            }
        }
        //insertion
        for(int i = 0; i < word.length() + 1; i++) {
            for(int c = 0; c < 26; c++) {
                StringBuilder insertion = new StringBuilder(word);
                String letterInsert = (char)('a' + c) + "";
                insertion.insert(i,letterInsert);
                distanceTwo.addAll(editDistanceOne(insertion.toString()));
            }
        }

        return distanceTwo;
    }

}
